# This project was developed by BigBenny Ogbuani
Note: The backend is assumed to be hosted on localhost:3001, while connected to an online database.
Kindly run this service on the backend to test application successfully.

The project took me about 4 hours and some minutes to complete. I referred to google for a few pointers
where I had code blockers, but that's all. I did it all by myself.

# Thanks!