
import './assets/css/main.css';
import HomePage from "./assessment/homepage";

function App() {
  return (
      <HomePage />
  );
}

export default App;
